package com.project.supermarvel

import android.content.Context

class smdata (private val context: Context) {
    val appcontext = context.applicationContext

    var names = appcontext.resources.getStringArray(R.array.data_name)
    var bases = appcontext.resources.getStringArray(R.array.data_base)
    var origins = appcontext.resources.getStringArray(R.array.data_origin)
    var logos = appcontext.resources.obtainTypedArray(R.array.data_logo)

    fun getDatas(): ArrayList<supermarvel> {
        val supermarvel = ArrayList<supermarvel>()
        for (i in names.indices) {
            val supermarvels = supermarvel(names[i], bases[i], origins[i], logos.getResourceId(i, 0))
            supermarvel.add(supermarvels)
        }
        return supermarvel
    }
}