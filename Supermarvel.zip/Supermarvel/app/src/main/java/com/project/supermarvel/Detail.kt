package com.project.supermarvel

import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import com.project.supermarvel.databinding.ActivityDetailBinding

class Detail : AppCompatActivity() {
    lateinit var view : ActivityDetailBinding
    lateinit var button2   : Button
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        view = ActivityDetailBinding.inflate(layoutInflater)
        setContentView(view.root)


        button2 = findViewById(R.id.button2)
        button2.setOnClickListener{finish()}

        val supermarvel = intent.getParcelableExtra<supermarvel>("DATA")
        view.tvDetailName.text = supermarvel?.name
        view.tvDetailOrigin.text = supermarvel?.origin
        view.tvDetailBase.text = supermarvel?.base
        supermarvel?.logo?.let { view.imageView.setImageResource(it) }
    }
}