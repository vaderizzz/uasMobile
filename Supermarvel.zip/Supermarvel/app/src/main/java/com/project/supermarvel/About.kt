package com.project.supermarvel

import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import com.bumptech.glide.Glide
import com.project.supermarvel.databinding.ActivityAboutBinding

class About : AppCompatActivity() {
    lateinit var view: ActivityAboutBinding
    lateinit var button: Button
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        view = ActivityAboutBinding.inflate(layoutInflater)
        setContentView(view.root)

        button = findViewById(R.id.button)
        button.setOnClickListener { finish() }
    }
}

