package com.project.supermarvel

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
data class supermarvel(
    var name: String,
    var base: String,
    var origin: String,
    var logo: Int
) :Parcelable
