package com.project.supermarvel

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.project.supermarvel.databinding.ItemHpBinding


class smadapter (
    val  data : ArrayList<supermarvel>,
    val onItemClick: (supermarvel) -> Unit
): RecyclerView.Adapter<smadapter.supermarvelViewHolder>() {
    class supermarvelViewHolder(val view: ItemHpBinding) : RecyclerView.ViewHolder(view.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): supermarvelViewHolder {
        val view = ItemHpBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return supermarvelViewHolder(view)
    }

    override fun getItemCount(): Int = data.size


    override fun onBindViewHolder(holder: supermarvelViewHolder, position: Int) {
        val (name, base, origin, logo) = data[position]
        holder.view.tvDetailName.text = name
        holder.view.tvItemBased.text = base
        holder.view.tvItemOrigin.text = origin
        holder.view.ivLogo.setImageResource(logo)
        holder.itemView.setOnClickListener {
            onItemClick(data[position])
        }
    }
}