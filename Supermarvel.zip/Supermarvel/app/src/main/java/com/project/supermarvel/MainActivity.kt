package com.project.supermarvel

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.Menu
import android.view.View
import android.view.MenuItem
import android.widget.ImageView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {
    private lateinit var rvsupermarvel: RecyclerView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        rvsupermarvel = findViewById(R.id.rv_supermarvel)
        rvsupermarvel.layoutManager = LinearLayoutManager(this)


        val data = ArrayList<supermarvel>()
        val names = resources.getStringArray(R.array.data_name)
        val bases = resources.getStringArray(R.array.data_base)
        val origins = resources.getStringArray(R.array.data_origin)
        val logos = resources.obtainTypedArray(R.array.data_logo)

        for (i in names.indices) {
            val hps = supermarvel(names[i], bases[i], origins[i], logos.getResourceId(i,0))
            data.add(hps)
        }

        val adapter = smadapter(data) { supermarvel ->
            showDetail(supermarvel)
        }

        rvsupermarvel.adapter = adapter
        rvsupermarvel.layoutManager = LinearLayoutManager(this)
    }

    private fun showDetail(data: supermarvel) {
        startActivity(
            Intent(this, Detail::class.java).putExtra("DATA", data)
        )
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.option_menu, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        startActivity(Intent(this@MainActivity,About::class.java))
        return super.onOptionsItemSelected(item)
    }


}